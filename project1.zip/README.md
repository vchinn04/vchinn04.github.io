HTML
1. I learned about and used the "hr" element in order to add visible dividers between the sections on the page.
2. The "br" tag was useful to separate entries in the table and separate lines in a paragraph.
3. The "abbr" element was useful to add descriptions to the abbreviations on the page via a tooltip that appears when hovering over the abbreviation.

CSS
1. I used "linear-gradient" in order to give the navigation bar a nice background gradient. 
2. I learned about  "@media max-width" and "min-width" and used it to make the website more responsive and change the layout for elements depending on screen size. 
3. The "text-transform" concept is very handy to consistently make text uppercase, without having issues such as mistyping some of the letters as lowercase, etc.
